<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
      .container {
    max-width: 400px;
    margin: 0 auto;
    padding: 20px;
    background-color: #f5f5f5;
    border-radius: 5px;
}

h1 {
    text-align: center;
    margin-top: 0;
}

form {
    margin-top: 20px;
}

label {
    display: block;
    margin-bottom: 5px;
}

input[type="text"],
input[type="password"] {
    width: 100%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

hr {
    margin-top: 20px;
    border: 0;
    border-top: 1px solid #ccc;
}

.login-btn {
    display: block;
    width: 100%;
    padding: 10px;
    margin-top: 10px;
    background-color: #4CAF50;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.register-link {
    display: inline-block;
    margin-top: 10px;
    text-decoration: none;
    color: #333;
}

.register-link:hover {
    text-decoration: underline;
}
</style>
</head>
<body>
    <div class="container">
        <h1>Login</h1>
        <form action="http://localhost/Web-project/login.php" method="POST">
            <label for="id">User ID</label>
            <input type="text" name="id" id="id" required><br>
            <label for="password">Password</label>
            <input type="password" name="password" id="password" required><br>
            <hr>
            <input type="submit" value="Login" class="login-btn">
            <a href="http://localhost/Web-project/register.php" class="register-link">Register</a>
        </form>
    </div>
</body>
</html>



<?php
 $servername = "localhost";
 $username = "root";
 $password = "";
 $dbname="lab8";
 
 // Create connection
 $conn = mysqli_connect($servername, $username, $password,$dbname);
 
 // Check connection
 if (!$conn) {
   die("Connection failed: " . mysqli_connect_error());
 }
 echo "Connected successfully";
  // Check connection
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = $_POST["id"];
  $password = $_POST["password"];

  if ($id == "" || $password == "") {
    echo "<h3 style='color: red;'>Field cannot be empty!</h3>";
    return;
  }



  $sql = $conn->prepare("SELECT * FROM users WHERE id = ?;");
  $sql->bind_param("s", $id);
  $sql->execute();
  $result = $sql->get_result();

  while ($row = $result->fetch_array(MYSQLI_NUM)) {
    if ($password != $row[3]) {
      echo "<h3 style='color: red;'>Incorrect password!</h3>";
      return;
    }

    $cookie = join("|", $row);
    setcookie("auth", $cookie);

    return header("http://localhost/Web-project/index.php");
  }
  echo "<h3 style='color: red;'>User not found!</h3>";

}
