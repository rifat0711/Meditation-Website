<!DOCTYPE html>
<html>
<head>
    <title>Emotional Morning Boost</title>
    <style>

header {
    background-color: #333;
    padding: 10px 0;
}

.hero {
    background-image: url('img3.jpg');
    background-size: cover;
    background-position: center;
    text-align: center;
    color: #FFFFFF;
    padding: 100px 0;
}

.hero-content h1 {
    font-size: 36px;
    margin-bottom: 20px;
}

.hero-content p {
    font-size: 18px;
    margin-bottom: 30px;
}

.courses-section {
    background-color: #FFFFFF;
    padding: 80px 0;
    text-align: center;
}

.courses-section h2 {
    font-size: 30px;
    margin-bottom: 20px;
}

.courses-section p {
    font-size: 18px;
    margin-bottom: 30px;
}
h1{
        text-align: center;
        }
</style>
</head>
<body>
<h1>Welcome to Emotional Morning Boost Course</h1>

<section class="hero">
        <div class="hero-content">
            <h1 style="color: blue;"> Emotional Morning Boost</h1>
            <p>Emotional Morning Boost" is a refreshing meditation session designed to uplift your mood, enhance positive emotions, and cultivate a sense of inner peace and joy. Start your day with this guided practice to embrace positivity and bring a renewed sense of emotional well-being.</p>
        </div>
    </section>
    <br>
    <form action="upload.php" method="post">
        <label for="videoLink">Upload Video Link:</label>
        <input type="text" id="videoLink" name="videoLink" required>
        <input type="submit" value="Submit">
    </form>
    <br> 
    <h2>Below is a list of some songs and video that will cheer you up. </h2>
    <audio controls>
        <source src="leva-eternity-149473.mp3" type="audio/mpeg">
        Your browser does not support the audio element.
    </audio>
    <video controls width="400" height="250">
        <source src="video8.mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>
    <video controls width="400" height="250">
        <source src="video1.mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>
    
    <a href="https://www.youtube.com/watch?v=jvdG-CCI4TE"><h4>LISTEN TO THIS FIRST THING IN THE MORNING<h4></a>
    <a href="https://www.youtube.com/watch?v=irBqtdVM-LU"><h4>Win The Morning, WIN THE DAY<h4></a>
    <a href="https://www.youtube.com/watch?v=yxo8-rQEDoM"><h4>Mind fresh song<h4></a>
    <a href="https://www.youtube.com/watch?v=ZdXgLhcQ1e4"><h4>Morning music motivation<h4></a>
    <a href="ps://www.youtube.com/watch?v=6OlH4vBLm_Y"><h4> Super Deep Meditation Music<h4></a>
    <a href="https://www.youtube.com/watch?v=eXbt6B7GloE"><h4>Feeling Full of Energy<h4></a>
    <a href="https://www.youtube.com/watch?v=x9UHAuyipx8"><h4>Acoustic Relaxing Music<h4></a>
</body>
</html>
