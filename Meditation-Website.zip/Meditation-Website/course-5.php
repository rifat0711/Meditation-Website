<!DOCTYPE html>
<html>
<head>
    <title>Brain Morning Boost</title>
    <style>

header {
    background-color: #333;
    padding: 10px 0;
}

.hero {
    background-image: url('img5.jpg');
    background-size: cover;
    background-position: center;
    text-align: center;
    color: #FFFFFF;
    padding: 100px 0;
}

.hero-content h1 {
    font-size: 36px;
    margin-bottom: 20px;
}

.hero-content p {
    font-size: 18px;
    margin-bottom: 30px;
}

.courses-section {
    background-color: #FFFFFF;
    padding: 80px 0;
    text-align: center;
}

.courses-section h2 {
    font-size: 30px;
    margin-bottom: 20px;
}

.courses-section p {
    font-size: 18px;
    margin-bottom: 30px;
}
h1{
        text-align: center;
        }
</style>
</head>
<body>
<h1>Welcome to Brain Morning Boost Course</h1>

<section class="hero">
        <div class="hero-content">
            <h1 style="color: red;"> Brain Morning Boost</h1>
            <p>Brain Morning Boost" is a stimulating meditation practice designed to awaken and sharpen your mental focus.</p>
        </div>
    </section>
    <br>
    <form action="upload.php" method="post">
        <label for="videoLink">Upload Video Link:</label>
        <input type="text" id="videoLink" name="videoLink" required>
        <input type="submit" value="Submit">
    </form>
    <br> 
    <h2>Below is a list of some songs and video that will cheer you up. </h2>
    <audio controls>
        <source src="leva-eternity-149473.mp3" type="audio/mpeg">
        Your browser does not support the audio element.
    </audio>
    <video controls width="400" height="250">
        <source src="video3.mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>
    <video controls width="400" height="250">
        <source src="video6.mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>
    
    <a href="https://www.youtube.com/watch?v=63-zv0qiU-Y"><h4>Super Intelligence | Guided Meditation<h4></a>
    <a href="https://www.youtube.com/watch?v=aQVYtm2aAr8"><h4>Guideline Meditation<h4></a>
    <a href="https://www.youtube.com/watch?v=pFl4TEjF600"><h4>MClear Your Mind From Overthinking<h4></a>
    <a href="https://www.youtube.com/watch?v=ZdXgLhcQ1e4"><h4>Morning music motivation<h4></a>
    <a href="ps://www.youtube.com/watch?v=6OlH4vBLm_Y"><h4> Super Deep Meditation Music<h4></a>
    <a href="https://www.youtube.com/watch?v=eXbt6B7GloE"><h4>Feeling Full of Energy<h4></a>
    <a href="https://www.youtube.com/watch?v=x9UHAuyipx8"><h4>Acoustic Relaxing Music<h4></a>
    
  
</body>
</html>
