<!DOCTYPE html>
<html>
    <style>
        /* Reset default styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Global styles */
body {
    font-family: Arial, sans-serif;
    line-height: 1.6;
}

.container {
    max-width: 960px;
    margin: 0 auto;
    padding: 20px;
}

/* Header styles */
header {
    background-color: #333;
    padding: 10px 0;
}

nav ul {
    list-style-type: none;
}

nav ul li {
    display: inline-block;
    margin-right: 20px;
}

nav ul li a {
    text-decoration: none;
    color: #fff;
}

/* Hero section styles */
.hero {
    background-image: url('bg2.jpg');
    background-size: cover;
    background-position: center;
    text-align: center;
    color: #d98345;
    padding: 100px 0;
}

.hero-content h1 {
    font-size: 36px;
    margin-bottom: 20px;
}

.hero-content p {
    font-size: 18px;
    margin-bottom: 30px;
}

.cta-button {
    display: inline-block;
    padding: 10px 20px;
    background-color: #fff;
    color: #333;
    text-decoration: none;
    border-radius: 5px;
    font-weight: bold;
    transition: background-color 0.3s ease;
}

.cta-button:hover {
    background-color: #f1f1f1;
}

/* About section styles */
.about-section {
    background-color: #e47842;
    padding: 80px 0;
    text-align: center;
}

.about-section h2 {
    font-size: 30px;
    margin-bottom: 20px;
}

.about-section p {
    font-size: 18px;
    margin-bottom: 30px;
}

/* Courses section styles */
.courses-section {
    background-color: #dd9551;
    padding: 80px 0;
    text-align: center;
}

.courses-section h2 {
    font-size: 30px;
    margin-bottom: 20px;
}

.courses-section p {
    font-size: 18px;
    margin-bottom: 30px;
}

/* Events section styles */
.events-section {
    background-color: #f1f1f1;
    padding: 80px 0;
    text-align: center;
}

.events-section h2 {
    font-size: 30px;
    margin-bottom: 20px;
}

.events-section p {
    font-size: 18px;
    margin-bottom: 30px;
}

/* Footer styles */
footer {
    background-color: #333;
    color: #fff;
    text-align: center;
    padding: 20px;
}

footer p {
    font-size: 14px;
}
</style>

<head>
    <title  >Meditation Website</title>
    <link rel="stylesheet" type="text/css" href="">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="course.php">Courses</a></li>
                <li><a href="upcoming-event.php">Events</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="index.php">Login/Signup</a></li>
            </ul>
        </nav>
    </header>

    <section class="hero">
        <div class="hero-content">
            <h1 style="color: blue;">Welcome to our Meditation Website</h1>
            <p>Find peace, clarity, and tranquility through meditation.</p>
            <a href="learn.php" class="cta-button">Learn More</a>
        </div>
    </section>

    <section class="about-section">
        <div class="about-content">
            <h2>About Us</h2>
            <p>Welcome to our Meditation Website, where we are dedicated to helping individuals find inner peace, clarity, and tranquility through the practice of meditation.</p>
        <p>At our website, we believe that meditation is a powerful tool for personal growth, well-being, and spiritual development. Our mission is to make the practice of meditation accessible to everyone, regardless of their background or experience level.</p>
    
        <p>Our courses are carefully crafted to provide guidance, support, and inspiration, helping you cultivate mindfulness, reduce stress, improve focus, and foster a sense of inner harmony. We combine traditional meditation techniques with modern approaches, ensuring a well-rounded and effective learning experience.</p>
       
        <p>Join us on this transformative journey and discover the profound benefits of meditation for your mind, body, and spirit. Start your meditation practice today and experience the positive impact it can have on your life.</p>
            <a href="about.php" class="cta-button">Explore</a>
        </div>
    </section>

    <section class="courses-section">
        <div class="courses-content">
            <h2>Our Courses</h2>
            <p>Discover our range of meditation courses designed to suit your needs.</p>
            <a href="course.php" class="cta-button">View Courses</a>
        </div>
    </section>

    <section class="events-section">
        <div class="events-content">
            <h2>Upcoming Events</h2>
            <p>Join us for our upcoming meditation events and workshops.</p>
            <a href="upcoming-event.php" class="cta-button">See Events</a>
        </div>
    </section>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Meditation Website. </p>
    </footer>
</body>
</html>
