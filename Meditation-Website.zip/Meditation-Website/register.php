<!DOCTYPE html>
<html>
<head>
  <title>Registration</title>
  <style>
    body {
      background-color: #f2f2f2;
      font-family: Arial, sans-serif;
    }
    
    h1 {
      color: #333333;
      text-align: center;
      margin-top: 50px;
    }
    
    form {
      max-width: 400px;
      margin: 0 auto;
      background-color: #ffffff;
      padding: 20px;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }
    
    label {
      font-weight: bold;
      display: block;
      margin-bottom: 5px;
    }
    
    input[type="text"],
    input[type="password"],
    input[type="email"],
    select {
      width: 100%;
      padding: 10px;
      border-radius: 5px;
      border: 1px solid #cccccc;
      margin-bottom: 10px;
      box-sizing: border-box;
    }
    
    input[type="submit"] {
      background-color: #337ab7;
      color: #ffffff;
      border: none;
      padding: 10px 20px;
      border-radius: 5px;
      cursor: pointer;
    }
    
    input[type="submit"]:hover {
      background-color: #286090;
    }
    
    a {
      display: block;
      text-align: center;
      margin-top: 10px;
      color: #337ab7;
    }
  </style>
</head>
<body>
  <h1>Registration</h1>
  <form action="http://localhost/Web-project/register.php" method="POST">
    <label for="id">ID</label>
    <input type="text" name="id">
    <label for="password">Password</label>
    <input type="password" name="password">
    <label for="cpassword">Confirm Password</label>
    <input type="password" name="cpassword">
    <label for="name">Name</label>
    <input type="text" name="name">
    <label for="email">Email</label>
    <input type="email" name="email">
    <label for="user_type">User Type [User/Admin]</label>
    <select type="text" name="user_type">
      <option value="user">User</option>
      <option value="admin">Admin</option>
    </select>
    <hr>
    <input type="submit" value="Register">
    <a href="http://localhost/Web-project/login.php">Login</a>
  </form>
</body>
</html>


<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = $_POST["id"];
  $password = $_POST["password"];
  $cpassword = $_POST["cpassword"];
  $name = $_POST["name"];
  $email = $_POST["email"];
  $role = $_POST["user_type"];

  if ($password != $cpassword) {
    echo "<h3 style='color: red;'>Password doesn't match!</h3>";
    return;
  }

  if ($id == "" || $password == "" || $name == "" || $email == "") {
    echo "<h3 style='color: red;'>Field cannot be empty!</h3>";
    return;
  }

  $conn = mysqli_connect("localhost", "root", "", "lab8");

  $sql = $conn->prepare("SELECT * FROM users WHERE id = ?;");
  $sql->bind_param("s", $id);
  $sql->execute();
  $result = $sql->get_result();

  while ($row = $result->fetch_array(MYSQLI_NUM)) {
    if ($row[0] == $id) {
      echo "<h3 style='color: red;'>User ID already exists!</h3>";
      return;
    }
  }

  $sql = $conn->prepare("INSERT INTO users (id, username, email, password, role) VALUES (?,?,?,?,?);");
  $sql->bind_param("sssss", $id, $name, $email, $password, $role);
  $sql->execute();

  return header("http://localhost/Web-project/login.php");
}
