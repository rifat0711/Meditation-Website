<!DOCTYPE html>
<html>
<head>
    <title>Brain Sleep Relaxation</title>
    <style>

header {
    background-color: #333;
    padding: 10px 0;
}

.hero {
    background-image: url('img1.jpg');
    background-size: cover;
    background-position: center;
    text-align: center;
    color: #FFFFFF;
    padding: 100px 0;
}

.hero-content h1 {
    font-size: 36px;
    margin-bottom: 20px;
}

.hero-content p {
    font-size: 18px;
    margin-bottom: 30px;
}

.courses-section {
    background-color: #FFFFFF;
    padding: 80px 0;
    text-align: center;
}

.courses-section h2 {
    font-size: 30px;
    margin-bottom: 20px;
}

.courses-section p {
    font-size: 18px;
    margin-bottom: 30px;
}
h1{
        text-align: center;
        }
</style>
</head>
<body>
<h1>Welcome to Brain Sleep Relaxation Course</h1>

<section class="hero">
        <div class="hero-content">
            <h1 style="color: blue;"> Brain Sleep Relaxation</h1>
            <p>Experience deep relaxation and rejuvenation with our guided meditation session designed to calm the mind and promote restful sleep.</p>
        </div>
    </section>
    <br>
    <form action="upload.php" method="post">
        <label for="videoLink">Upload Video Link:</label>
        <input type="text" id="videoLink" name="videoLink" required>
        <input type="submit" value="Submit">
    </form>
    <br> 
    <h2>Below is a list of some songs and video that will cheer you up. </h2>
    <audio controls>
        <source src="leva-eternity-149473.mp3" type="audio/mpeg">
        Your browser does not support the audio element.
    </audio>
    <video controls width="400" height="250">
        <source src="video3.mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>
    <video controls width="400" height="250">
        <source src="video4.mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>
    
    <a href="https://www.youtube.com/watch?v=xQ6xgDI7Whc"><h4>Sleep Music Delta Waves: Relaxing Music to Help you Sleep, Deep Sleep, Inner Peace<h4></a>
    <a href="https://www.youtube.com/watch?v=TcXnFoEGXOQ"><h4>Relaxing Sleep Music<h4></a>
    <a href="https://www.youtube.com/watch?v=Yo-vdzosRkw"><h4>Stop Overthinking - Slow Down An Overactive Mind - Calm Down And Relax<h4></a>
    <a href="https://www.youtube.com/watch?v=5H_kiCyo0Bs"><h4>Deep Sleep Music for Stress Relief: Healing Delta Binaural Beats for Brain Power<h4></a>
    <a href="https://www.youtube.com/watch?v=Kk7--moip1w"><h4> Super Deep Meditation Music<h4></a>
    <a href="https://www.youtube.com/watch?v=eXbt6B7GloE"><h4>ULTIMATE DEEP SLEEP music- Healing INSOMNIA<h4></a>
    <a href="https://www.youtube.com/watch?v=x9UHAuyipx8"><h4>Acoustic Relaxing Music<h4></a>
</body>
</html>
