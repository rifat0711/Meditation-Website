<!DOCTYPE html>
<html>
<head>
    <title>Course List</title>
    <style>
        .image-container {
            text-align: center;
            display: inline-block;
            margin: 10px;
            width: 200px;
            padding-left: 80px;
        }

        .image-container img {
            width: 100%;
        }

        .image-name {
            font-weight: bold;
            margin-top: 10px;
        }
        h1{
        text-align: center;
        }
    </style>
</head>
<body>
<h1 style="color: blue;">It only takes 10 minutes to revive your life.</h1>
    <div class="row">
        <div class="image-container">
            <a href="course-1.php"><img src="img1.jpg" alt="Image 1"></a>
            <p class="image-name">Brain Sleep Relaxation</p>
        </div>
        <div class="image-container">
            <a href="course-2.php"><img src="img2.jpg" alt="Image 2"></a>
            <p class="image-name">Emotional Sleep Relaxation</p>
        </div>
        <div class="image-container">
            <a href="course-3.php"><img src="img3.jpg" alt="Image 3"></a>
            <p class="image-name">Emotional Morning Boost</p>
        </div>
    </div>
    <div class="row">
        <div class="image-container">
            <a href="course-4.php"><img src="img4.jpg" alt="Image 4"></a>
            <p class="image-name">Body Sleep Reflexion</p>
        </div>
        <div class="image-container">
            <a href="course-5.php"><img src="img5.jpg" alt="Image 5"></a>
            <p class="image-name">Brain Morning Boost</p>
        </div>
        <div class="image-container">
            <a href="course-6.php"><img src="img6.jpg" alt="Image 6"></a>
            <p class="image-name">Body Morning Boost</p>
        </div>
    </div>
</body>
</html>
