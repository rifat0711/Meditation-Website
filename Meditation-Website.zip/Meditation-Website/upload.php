<?php
$servername = "localhost";  
$username = "root";  
$password = "";  
$dbname = "lab8";  

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connect Successfully";

$videoLink = $_POST['videoLink'];

$sql = "INSERT INTO videos  VALUES ('$videoLink')";

if ($conn->query($sql) === TRUE) {
    echo "Video link uploaded successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$sql = "SELECT * FROM videos"; 

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        
        $link = $row["link_column_name"]; 

        
        echo "<a href='$link'>Link Text<br></a>"; 
    }
} else {
    echo "No data found";
}


$conn->close();
?>
