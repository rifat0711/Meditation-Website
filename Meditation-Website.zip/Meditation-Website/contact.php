<!DOCTYPE html>
<html>
<head>
    <title>Contact Us</title>
    <style>
        
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        background-color: #f5f5f5;
        font-family: Arial, sans-serif;
        color: #333;
    }

    header {
        background-color: #fff;
        padding: 20px;
        text-align: center;
    }

    header h1 {
        font-size: 30px;
        margin-bottom: 10px;
        color: #333;
    }

    .main-content {
        max-width: 960px;
        margin: 20px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
    }

    .contact-form {
        margin-top: 20px;
    }

    .contact-form h2 {
        font-size: 24px;
        margin-bottom: 10px;
        color: #333;
    }

    .contact-form input,
    .contact-form textarea {
        display: block;
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-size: 14px;
    }

    .contact-form button {
        background-color: #333;
        color: #fff;
        border: none;
        padding: 10px 20px;
        border-radius: 4px;
        font-size: 14px;
        cursor: pointer;
    }

    .contact-form button:hover {
        background-color: #555;
    }


    </style>
</head>
<body>
    <header>
        <h1>Contact Us</h1>
    </header>
    <div class="main-content">
        <div class="contact-form">
            <h2>Get in touch</h2>
            <form method="post" action="contact-sql.php">
                <input type="text" name="name" placeholder="Your Name" required>            
                <input type="email" name="email" placeholder="Your Email" required>
                <textarea name="message" placeholder="Your Message" required></textarea>
                <button type="submit">Submit</button>

            </form>
        </div>
    </div>
</body>
</html>
