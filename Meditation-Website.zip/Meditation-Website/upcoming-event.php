<!DOCTYPE html>
<html>

<head>
    <title>Upcoming Events</title>
    <style>
        .event-list {
    margin-top: 20px;
}

.event {
    margin-bottom: 20px;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.event h2 {
    margin-top: 0;
}

.event p {
    margin-bottom: 5px;
}
h1{
        text-align: center;
        }
</style>
   
</head>
<body>
    <h1>Upcoming Events</h1>

    <div class="event-list">
        <?php
        // PHP code to fetch and display upcoming events
        ?>
    </div>
</body>
</html>