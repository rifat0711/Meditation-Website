<!DOCTYPE html>
<html>
<head>
    <title>Emotional Sleep Relaxation</title>
    <style>

header {
    background-color: #333;
    padding: 10px 0;
}

.hero {
    background-image: url('img2.jpg');
    background-size: cover;
    background-position: center;
    text-align: center;
    color: #FFFFFF;
    padding: 100px 0;
}

.hero-content h1 {
    font-size: 36px;
    margin-bottom: 20px;
}

.hero-content p {
    font-size: 18px;
    margin-bottom: 30px;
}

.courses-section {
    background-color: #FFFFFF;
    padding: 80px 0;
    text-align: center;
}

.courses-section h2 {
    font-size: 30px;
    margin-bottom: 20px;
}

.courses-section p {
    font-size: 18px;
    margin-bottom: 30px;
}
h1{
        text-align: center;
        }
</style>
</head>
<body>
<h1>Welcome to Emotional Sleep Relaxation</h1>

<section class="hero">
        <div class="hero-content">
            <h1 style="color: blue;"> Emotional Sleep Relaxation</h1>
            <p>Experience deep relaxation and rejuvenation with our guided meditation session designed to calm the mind and promote restful sleep.</p>
        </div>
    </section>
    <br>
    <form action="upload.php" method="post">
        <label for="videoLink">Upload Video Link:</label>
        <input type="text" id="videoLink" name="videoLink" required>
        <input type="submit" value="Submit">
    </form>
    <br> 
    
    <h2>Below is a list of some songs and video that will cheer you up. </h2>
    <p> funny video</p>
    <video controls width="400" height="250">
        <source src="video1.mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>
    <video controls width="400" height="250">
        <source src="video2.mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>
    <a href="https://www.youtube.com/watch?v=Cj8CE9gKnek"><h4>Relaxing Sleep Music with Rain Sounds & Thunder<h4></a>
    <a href="https://www.youtube.com/watch?v=PwklenguLdU&t=52s"><h4>Emotional//Deep Night Sleeping Song<h4></a>
    <a href="https://www.youtube.com/watch?v=rXgWUyziA68"><h4>Emotional Release Music<h4></a>
    <a href="https://www.youtube.com/watch?v=5H_kiCyo0Bs"><h4>Deep Sleep Music for Stress Relief: Healing Delta Binaural Beats for Brain Power<h4></a>
    <a href="https://www.youtube.com/watch?v=39uMLYTh40Q"><h4> Bengali Lofi Songs<h4></a>
    <a href="https://www.youtube.com/watch?v=pbj55WgpnGE"><h4>Night Drive Mashup<h4></a>
    <a href="https://www.youtube.com/watch?v=-MP5ab90K3o"><h4>Alofi Emotional<h4></a>
</body>
</html>
