<!DOCTYPE html>
<html>
<head>
    <title>Learn More</title>
    <style>
    /* Reset some default styling */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    /* Set the body background and font styles */
    body {
        background-color: #f5f5f5;
        font-family: Arial, sans-serif;
        color: #333;
        background-image: url("bg2.jpg");
    }

    /* Style the header section */
    header {
        background-color: #fff;
        padding: 20px;
        text-align: center;
        background-image: url('bg2.jpg');
    }

    header h1 {
        font-size: 30px;
        margin-bottom: 10px;
        color: #333;
    }

    /* Style the main content section */
    .main-content {
        max-width: 960px;
        margin: 20px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
        background-image: url('bg2.jpg');
    }

    .learn-more-section h2,
    .benefits-section h2 {
        font-size: 24px;
        margin-bottom: 10px;
        color: #333;
    }

    .learn-more-section p,
    .benefits-section ul {
        margin-bottom: 10px;
    }

    .benefits-section ul {
        list-style-type: disc;
        margin-left: 20px;
    }
</style>

</head>
<body>
    <header>
        <h1>Learn More</h1>
    </header>
   
    <div class="main-content">
        <div class="learn-more-section">
            <h2>Why Meditate?</h2>
            <p>Find peace, clarity, and tranquility through meditation.</p>
        </div>
        <div class="benefits-section">
            <h2>Benefits of Meditation</h2>
            <ul>
                <li>Reduces stress and anxiety</li>
                <li>Improves focus and concentration</li>
                <li>Promotes emotional well-being</li>
                <li>Enhances self-awareness</li>
                <li>Increases relaxation and inner peace</li>
            </ul>
        </div>
    </div>
</body>
</html>
