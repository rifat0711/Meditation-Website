<?php
if (isset($_COOKIE['auth'])) {
  setcookie("auth", "", time() - 3600);
  return header("Location: http://localhost/Web-project/login.php");
}
